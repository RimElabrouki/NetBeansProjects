/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author Rim
 */
@Entity
@Table(name = "candidato", catalog = "concurso", schema = "")
@NamedQueries({
    @NamedQuery(name = "Candidato.findAll", query = "SELECT c FROM Candidato c")
    , @NamedQuery(name = "Candidato.findByIdcandidato", query = "SELECT c FROM Candidato c WHERE c.idcandidato = :idcandidato")
    , @NamedQuery(name = "Candidato.findByNombre", query = "SELECT c FROM Candidato c WHERE c.nombre = :nombre")
    , @NamedQuery(name = "Candidato.findByCiudad", query = "SELECT c FROM Candidato c WHERE c.ciudad = :ciudad")
    , @NamedQuery(name = "Candidato.findByFechainscripcion", query = "SELECT c FROM Candidato c WHERE c.fechainscripcion = :fechainscripcion")
    , @NamedQuery(name = "Candidato.findByFinalista", query = "SELECT c FROM Candidato c WHERE c.finalista = :finalista")
    , @NamedQuery(name = "Candidato.findByIdcategoria", query = "SELECT c FROM Candidato c WHERE c.idcategoria = :idcategoria")
    , @NamedQuery(name = "Candidato.findByIdaudicion", query = "SELECT c FROM Candidato c WHERE c.idaudicion = :idaudicion")})
public class Candidato implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idcandidato")
    private Integer idcandidato;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "ciudad")
    private String ciudad;
    @Basic(optional = false)
    @Column(name = "fechainscripcion")
    @Temporal(TemporalType.DATE)
    private Date fechainscripcion;
    @Basic(optional = false)
    @Column(name = "finalista")
    private boolean finalista;
    @Basic(optional = false)
    @Column(name = "idcategoria")
    private int idcategoria;
    @Column(name = "idaudicion")
    private Integer idaudicion;

    public Candidato() {
    }

    public Candidato(Integer idcandidato) {
        this.idcandidato = idcandidato;
    }

    public Candidato(Integer idcandidato, String nombre, String ciudad, Date fechainscripcion, boolean finalista, int idcategoria) {
        this.idcandidato = idcandidato;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.fechainscripcion = fechainscripcion;
        this.finalista = finalista;
        this.idcategoria = idcategoria;
    }
  

    public Candidato(int idcandidato, String nombre, String ciudad, Date fechainscripcion, boolean finalista, int idcategoria, int idaudicion) {
        this.idcandidato = idcandidato;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.fechainscripcion = fechainscripcion;
        this.finalista = finalista;
        this.idcategoria = idcategoria;
    }

    public Candidato(int idcandidato, String nombre, String ciudad) {
        this.idcandidato = idcandidato;
        this.nombre = nombre;
        this.ciudad = ciudad;
    }

    public Candidato(int i, int i0, int i1, String windows_8) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Integer getIdcandidato() {
        return idcandidato;
    }

    public void setIdcandidato(Integer idcandidato) {
        Integer oldIdcandidato = this.idcandidato;
        this.idcandidato = idcandidato;
        changeSupport.firePropertyChange("idcandidato", oldIdcandidato, idcandidato);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        String oldNombre = this.nombre;
        this.nombre = nombre;
        changeSupport.firePropertyChange("nombre", oldNombre, nombre);
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        String oldCiudad = this.ciudad;
        this.ciudad = ciudad;
        changeSupport.firePropertyChange("ciudad", oldCiudad, ciudad);
    }

    public Date getFechainscripcion() {
        return fechainscripcion;
    }

    public void setFechainscripcion(Date fechainscripcion) {
        Date oldFechainscripcion = this.fechainscripcion;
        this.fechainscripcion = fechainscripcion;
        changeSupport.firePropertyChange("fechainscripcion", oldFechainscripcion, fechainscripcion);
    }

    public boolean getFinalista() {
        return finalista;
    }

    public void setFinalista(boolean finalista) {
        boolean oldFinalista = this.finalista;
        this.finalista = finalista;
        changeSupport.firePropertyChange("finalista", oldFinalista, finalista);
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        int oldIdcategoria = this.idcategoria;
        this.idcategoria = idcategoria;
        changeSupport.firePropertyChange("idcategoria", oldIdcategoria, idcategoria);
    }

    public Integer getIdaudicion() {
        return idaudicion;
    }

    public void setIdaudicion(Integer idaudicion) {
        Integer oldIdaudicion = this.idaudicion;
        this.idaudicion = idaudicion;
        changeSupport.firePropertyChange("idaudicion", oldIdaudicion, idaudicion);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcandidato != null ? idcandidato.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Candidato)) {
            return false;
        }
        Candidato other = (Candidato) object;
        if ((this.idcandidato == null && other.idcandidato != null) || (this.idcandidato != null && !this.idcandidato.equals(other.idcandidato))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Candidato[ idcandidato=" + idcandidato + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }

}
