/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validacion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Rim
 */
public class ConcursoException extends Exception {

    public ConcursoException(String msg) {
        super(msg);
    }

    /**
     * Función que se le pasa un número y comprueba si es válida
     * para setearla como valor para el id
     *
     * Long que sea único y positivo
     *
     * Obligatorio: sí
     *
     * Validación usada para los campos: - id
     *
     * Ejemplos válidos: 
     *
     * @param id long
     * @return true de ser un valor válido para un id y false si es que no
     */
    
    public static boolean validarId (long id) {
        boolean ret = true;
        
        if (id <= 0) {
            ret = false;
        }
        
        return ret;
    }
    /**
     * Función que se le pasa una cadena de caracteres y comprueba si es válida
     * para setearla como valor para el nombre
     *
     * Cadena de caracteres [3-50 caracteres] [a-z, A-Z], tildes, dieresis y
     * espacios
     *
     * Obligatorio: sí
     *
     * Validación usada para los campos: - nombre, apellido (socio, evento,
     * proveedor, genero) - autor, editorial (libro) - tipo (concurso)
     *
     * Ejemplos válidos: Marcos Gutierrez; Salvat...
     *
     * @param nombre cadena de caracteres
     * @return true de ser un valor válido para un nombre y false si es que no
     */
    public static boolean validarNombre(String nombre) {
        boolean ret = true;

        if (nombre.isEmpty()) {
            ret = false;
        }
        if (nombre.length() < 1 || nombre.length() > 150) {
            ret = false;
        }
        for (char c : nombre.toCharArray()) {
            if (Character.isDigit(c) || (!Character.isLetter(c) && c != ' ')) {
                ret = false;
                break;
            }

        }
        return ret;
    }

    /**
     * Función que se le pasa una cadena de caracteres y comprueba si es válida
     * para setearla como valor para el teléfono
     *
     * Cadena de caracteres numérica [0-9] que admite espacios y de tamaño fijo
     * a 9 caracteres
     *
     * Obligatorio: sí
     *
     * Validación usada para los campos: - telefono (socio, proveedor)
     *
     * Ejemplos válidos: 600436911; 722 13 00 53; 620 345 876
     *
     * @param tlfn cadena de caracteres
     * @return true de ser un valor válido para el teléfono y false si es que no
     */
    public static boolean validarTlfn(String tlfn) {
        boolean ret = true;
        if (tlfn.isEmpty()) {
            ret = false;
        }
        if (tlfn.length() != 11 && tlfn.length() != 12 && tlfn.length() != 9) {
            ret = false;
        }
        for (char c : tlfn.toCharArray()) {
            if ((Character.isLetter(c) && c != ' ') || !Character.isDigit(c)) {
                ret = false;
                break;
            }
        }
        return ret;
    }

    /**
     * Función que se le pasa un campo y comprueba si es válida para setearla
     * como valor para varios campos
     *
     * Cadena de caracteres [3-150] [a-z, A-Z], tildes, dieresis, signos de
     * puntuacion, exclamacion e interrogacion, digitos [0-9], simbolos
     * alfanumericos y caracteres especiales
     *
     * Obligatorio: sí
     *
     * Validación usada para los campos: - titulo (DVD) - libro (lectura) -
     * nombre (libro) - pelicula (visionado) - direccion (socio) - ubicacion
     * (estanteria) - motivo (penalizacion) - concurso (premio)
     *
     * Ejemplos válidos: 300 la pelicula; El guardian entre el centeno, C/ Siglo
     * XX; seccion A, estanteria f, 2ª balda de "Poesia"...
     *
     * @param otros cadena de caracteres
     * @return true de ser un valor válido para ciertos campos y false si es que
     * no
     */
    public static boolean validarOtrosCampos(String otros) {
        boolean ret = true;
        if (otros.isEmpty()) {
            ret = false;
        }

        if (otros.length() < 3 || otros.length() > 150) {
            ret = false;
        }
        return ret;
    }

    /**
     * Función que se le pasa una cadena de caracteres y comprueba si es válida
     * para setearla como valor para el estado de la devolucion
     *
     * Cadena de caracteres {"pendiente", "parcial", "completo"}
     *
     * Obligatorio: si
     *
     * Validación usada para los campos: - devolucion (estado)
     *
     * Ejemplos válidos:
     *
     * @param devo cadena de caracteres
     * @return true de ser un valor válido para la devolucion y false si es que
     * no
     */
    public static boolean validarDevolucion(String devo) {
        boolean ret = true;
        if (devo.isEmpty()) {
            ret = false;
        }
        if (devo != "pendiente" && devo != "parcial" && devo != "completo") {
            ret = false;
        }
        return ret;
    }

    /**
     * Función que se le pasa un entero y comprueba si es válida para setearla
     * como valor para el motivo de una penaliz
     *
     * Entero [0-9] en horas
     *
     * Obligatorio: si
     *
     * Validación usada para los campos: - duracion (curso)
     *
     * Ejemplos válidos: 30, 400
     *
     * @param dur entero
     * @return true de ser un valor válido para la duracion y false si es que no
     */
    public static boolean validarDuracion(double dur) {
        boolean ret = true;

        if (dur < 1 || dur > 1000) {
            ret = false;
        }
        return ret;
    }

    /**
     * Función que se le pasa un entero y comprueba si es válida para setearla
     * como valor para el aula
     *
     * Entero [0-9]
     *
     * Obligatorio: si
     *
     * Validación usada para los campos: - aula (curso, visionado)
     *
     * Ejemplos válidos: 12, 48
     *
     * El primer numero indica la planta y el segundo el aula
     *
     * @param aula entero
     * @return true de ser un valor válido para un aula y false si es que no
     */
    public static boolean validarAula(int aula) {
        boolean ret = true;

        if (aula < 11 || aula > 48) {
            ret = false;
        }
        return ret;
    }
    
    /**
     * Función que se le pasa un Date y comprueba si es válida
     * como valor para el fecha de un Evento y Prestamo y Penalizacion y lote
     * El método getInstance () :se usa para obtener un calendario usando
     * la zona horaria actual y la configuración regional del sistema
     * @param fechaHora Date
     * @return true si el time is correcto y si hay un Excepcion va mostrar un mesaje y devuelve un false
     */

    public static boolean isValidFecha(Date fechaHora) {
        // create un Calendario
        Calendar cal = Calendar.getInstance();
        // cambiar el estado indulgente ( change lenient state)
        cal.setLenient(false);
        //asigna el calendario para dar un fechaHora(assigns calendar to given date)
        cal.setTime(fechaHora);
        try {
            cal.getTime();
            return true;
        } catch (Exception e) {
            System.out.println("Formato de fecha inválido");
            return false;
        }
    }
 /**
  * Función que se le pasa un Date y comprueba si es válida para setearla
  * como valor para el fecha de un Evento y Prestamo y Penalizacion y lote
  * df.parse(fechaEvent):Transforma una cadena con la representación de una fecha y hora, y devuelve 
  * el número de milisegundos desde las 00:00:00 del 1 de enero de 1970, hasta la fechaEvent.
  * @param fechaEvent String
  * @return return df.parse(fechaEvent) y si hay un Exception devuele Null
  */

  public static Date isValidFechaString (String fechaEvent) {
        try {
            // forma de fecha
            String DATE_FORMAT = "yyyy-MM-dd";
            // formatear la fecha usando SimpleDateFormat
            SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT);
            // cambiar el estado indulgente ( change lenient state)
            df.setLenient(false);
            return df.parse(fechaEvent);
        } catch (ParseException e) {
            return null;
        }
    }
    //para validar todos los atributus de tipo String
     public static boolean isValidString(String str) {
          if (str.isEmpty()) {
            return false;
        }
        if (str.length() < 2 || str.length() > 150) {
            return false;
        }
        for (char c : str.toCharArray()) {
            //si no es un digito y no es una letra y no es un espacio 
            //significa que es un caracter especial return false
            if (!Character.isDigit(c) && !Character.isLetter(c) && c != ' ') {
                return false;
            }
        }
        return true;
    }

     /**
      *Función que se le pasa un entero y comprueba si es válida para setearla
      * como valor para el id
      * valores validos: 0 hasta MAX_VALUE
      * valores invalidos : menos de 0
      * valor por defecto :0
      * @param id entero
      * @return true si es un valor válido para un id y false si es no
      */
     
    public static boolean isValidIdEvent(int id) {
       boolean ret = true;
     if(id <= 0 || id > Integer.MAX_VALUE )
          ret = false;
        return ret;
    }
    
    
    
    public static boolean validarDNI(String dni) {

        String letraMayuscula = ""; //Guardaremos la letra introducida en formato mayúscula

        // Aquí excluimos cadenas distintas a 9 caracteres que debe tener un dni y también si el último caracter no es una letra
        if (dni.length() != 9 || Character.isLetter(dni.charAt(8)) == false) {
            return false;
        }

        // Al superar la primera restricción, la letra la pasamos a mayúscula
        letraMayuscula = (dni.substring(8)).toUpperCase();

        // Por último validamos que sólo tengo 8 dígitos entre los 8 primeros caracteres y que la letra introducida es igual a la de la ecuación
        // Llamamos a los métodos privados de la clase soloNumeros() y letraDNI()
        if (ConcursoException.soloNumeros(dni) == true && ConcursoException.letraDNI(dni).equals(letraMayuscula)) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean soloNumeros(String dni) {

        int i, j = 0;
        String numero = ""; // Es el número que se comprueba uno a uno por si hay alguna letra entre los 8 primeros dígitos
        String miDNI = ""; // Guardamos en una cadena los números para después calcular la letra
        String[] unoNueve = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

        for (i = 0; i < dni.length() - 1; i++) {
            numero = dni.substring(i, i + 1);

            for (j = 0; j < unoNueve.length; j++) {
                if (numero.equals(unoNueve[j])) {
                    miDNI += unoNueve[j];
                }
            }
        }

        if (miDNI.length() != 8) {
            return false;
        } else {
            return true;
        }
    }

    private static String letraDNI(String dni) {
        // El método es privado porque lo voy a usar internamente en esta clase, no se necesita fuera de ella

        // pasar miNumero a integer
        int miDNI = Integer.parseInt(dni.substring(0, 8));
        int resto = 0;
        String miLetra = "";
        String[] asignacionLetra = {"T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"};

        resto = miDNI % 23;

        miLetra = asignacionLetra[resto];

        return miLetra;
    }
    
}
