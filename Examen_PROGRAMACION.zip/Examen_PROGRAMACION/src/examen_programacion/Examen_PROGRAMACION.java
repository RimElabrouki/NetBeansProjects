/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_programacion;

import Clases_DAO.CandidatoDAO;
import Clases_DAO.IndividualDAO;
import entidades.Candidato;

/**
 *
 * @author Rim
 */
public class Examen_PROGRAMACION {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Candidato c1 = new Candidato(4, 300, 2, "Windows 8");
        Candidato c2 = new Candidato(5, 1500, 4, "Linux Suse");
        Candidato c3 = new Candidato(6, 512, 8, "iOS");
        CandidatoDAO cDAO = new CandidatoDAO();
        cDAO.insertarCandidato(c1);
        cDAO.insertarCandidato(c2);
        cDAO.insertarCandidato(c3);
        cDAO.filtrarCandidatosPorCiudad("Santander");

        IndividualDAO iDAO = new IndividualDAO();

        iDAO.filtrarIndividualPorEdad(50);
        
    }

}
